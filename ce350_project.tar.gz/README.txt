CE 350 PROJECT ASSIGNMENT

-----------------------------------------------------------------------------------------
Instructor: Kaya Oğuz
This project has been developed by Ozan Yücel - 20190602043 & Mert Yıldız - 20190613031

-----------------------------------------------------------------------------------------
--- USAGE ---
All you need to do is unpack the script and run it from console. 
No extra configuration is required.

